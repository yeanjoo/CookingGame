package cookingCoding;

public class CookingGui {

	public static void main(String[] args) {
		CookingMain  a = new CookingMain();
	}

}
